#ifndef HEADER_H
#define HEADER_H

#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
#include <cmath>
#include <vector>
#include <iomanip>

#include <Eigen\Dense> //for Eigen library

using namespace std;
using namespace Eigen;

#define PI 3.14159265358979

class Point{
private:
public:
	double ID, X, Y, Z;
//public:
	//get_values(double& double)
};

class Plane {
private:
	double nx, ny, nz, d;
public:
	Plane() = default;
	Plane(double x, double y, double z, double D) : nx(x), ny(y), nz(z), d(D) {};

	double DistPlane2Point(Point p) const;
	void set_Plane(const double& a, const double& b, const double& c, const double& D);
	void get_Plane(double& a, double& b, double& c, double& D) const;

	void fit_Plane(vector <Point>& vec);
};


#endif