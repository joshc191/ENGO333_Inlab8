#include "Header.h"

double Plane::DistPlane2Point(Point p) const
{
	double a = abs(p.X*nx + p.Y*ny + p.Z*nz);
	double b = sqrt(pow(nx, 2) + pow(ny, 2) + pow(nz, 2));
	return a / b;
}

void Plane::set_Plane(const double& a, const double& b, const double& c, const double& D) {
	nx = a;
	ny = b;
	nz = c;
	d = D;
}

void Plane::get_Plane(double& a, double& b, double& c, double& D) const {
	a = nx;
	b = ny;
	c = nz;
	D = d;
}

void Plane::fit_Plane(vector <Point>& vec) {

	//Part 1
	MatrixXd A(vec.size(), 3);
	MatrixXd L;
	L.setOnes(vec.size(), 1);

	for (int i = 0; i < A.rows(); i++) {
		A(i, 0) = vec[i].X;
		A(i, 1) = vec[i].Y;
		A(i, 2) = vec[i].Z;
	}

	MatrixXd delta_x = (A.transpose() * A).ldlt().solve( (A.transpose() * L) );
	double u = delta_x.norm();
	delta_x /= u;

	nx = delta_x(0,0);
	ny = delta_x(1,0);
	nz = delta_x(2,0);
	d = (-1) / u;

	//Part 2

	MatrixXd A2(vec.size(), 4);
	MatrixXd W(vec.size(), 1);
	MatrixXd H(1, 4);
	MatrixXd Hc(1, 1);
	MatrixXd N, U, Uc(U.rows() + Hc.rows(), U.cols), K(N.rows() + H.rows(), N.cols() + H.rows()) ;


	for (int i = 0; i <= 10; i++) {
		u = sqrt(pow(nx, 2) + pow(ny, 2) + pow(nz, 2));

		for (int j = 0; j < vec.size(); j++) {
			A2(i, 0) = vec[i].X;
			A2(i, 1) = vec[i].Y;
			A2(i, 2) = vec[i].Z;
			A2(i, 3) = 1;
			W(i, 0) = (vec[i].X*nx + vec[i].Y*ny + vec[i].Z*nz + d)*(-1);
		}

		H << nx / u, ny / u, nz / u, 0;

		
		Hc << 1 - u;

		N = A2.transpose() * A2;
		U = A2.transpose() * W;
		Uc << U,
			Hc;
		K << N, H.transpose(),
			H, 0;

		delta_x = K.ldlt().solve(Uc);
		nx += delta_x(0, 1);
		ny += delta_x(0, 2);
		nz += delta_x(0, 3);
		d += delta_x(0, 4);
	}
}
